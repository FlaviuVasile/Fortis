<?php
require_once 'db.php'; 

header("Content-Type: application/json");

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(["error" => "Method not allowed"]);
    exit;
}

if (!isset($_GET['gameId']) || !isset($_GET['playerId'])) {
    http_response_code(400);
    echo json_encode(["error" => "Missing gameId or playerId"]);
    exit;
}

$gameId = intval($_GET['gameId']);
$playerId = intval($_GET['playerId']);

$input = json_decode(file_get_contents('php://input'), true);

if (!isset($input['resource_type'])) {
    http_response_code(400);
    echo json_encode(["error" => "Missing resource_type"]);
    exit;
}

$resourceType = $input['resource_type'];
$allowedResources = ['wood', 'clay', 'food', 'stone', 'reed'];

if (!in_array($resourceType, $allowedResources)) {
    http_response_code(400);
    echo json_encode(["error" => "Invalid resource_type"]);
    exit;
}

$stmt = $db->prepare("SELECT id FROM games WHERE id = ?");
$stmt->execute([$gameId]);
$game = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$game) {
    http_response_code(404);
    echo json_encode(["error" => "Game not found"]);
    exit;
}

$stmt = $db->prepare("SELECT id FROM players WHERE id = ? AND game_id = ?");
$stmt->execute([$playerId, $gameId]);
$player = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$player) {
    http_response_code(404);
    echo json_encode(["error" => "Player not found in this game"]);
    exit;
}

$stmt = $db->prepare("SELECT $resourceType FROM board_resources WHERE game_id = ?");
$stmt->execute([$gameId]);
$resource = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$resource || $resource[$resourceType] <= 0) {
    http_response_code(400);
    echo json_encode([
        "error" => "Resource not available",
        "remaining" => $resource[$resourceType]
    ]);
    exit;
}

$stmt = $db->prepare("UPDATE board_resources SET $resourceType = $resourceType - 1 WHERE game_id = ?");
$stmt->execute([$gameId]);

$stmt = $db->prepare("UPDATE player_resources 
                      SET $resourceType = $resourceType + 1 
                      WHERE player_id = ?");
$stmt->execute([$playerId]);

$stmt = $db->prepare("SELECT $resourceType FROM board_resources WHERE game_id = ?");
$stmt->execute([$gameId]);
$updatedBoardResource = $stmt->fetch(PDO::FETCH_ASSOC)[$resourceType];

$stmt = $db->prepare("SELECT $resourceType FROM player_resources WHERE player_id = ?");
$stmt->execute([$playerId]);
$updatedPlayerResource = $stmt->fetch(PDO::FETCH_ASSOC)[$resourceType];

http_response_code(200);
echo json_encode([
    "message" => "Resource gathered successfully",
    "board_resource" => $updatedBoardResource,
    "player_resource" => $updatedPlayerResource
]);
