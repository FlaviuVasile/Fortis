<?php
header("Content-Type: application/json");

$dsn = "mysql:host=localhost;dbname=agricola;charset=utf8mb4";
$user = "root";
$pass = "1111"; 
$options = [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION];

try {
    $conn = new PDO($dsn, $user, $pass, $options);
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(["error" => "Eroare conexiune BD"]);
    exit;
}

// Rutare
$method = $_SERVER['REQUEST_METHOD'];
$uri = explode("/", trim($_SERVER['REQUEST_URI'], "/"));

if ($uri[1] !== "players") {
    http_response_code(404);
    echo json_encode(["error" => "Resursă inexistentă"]);
    exit;
}

$id = isset($uri[2]) ? intval($uri[2]) : null;

switch ($method) {
    case 'GET':
        if ($id === null) {
            $stmt = $conn->query("SELECT * FROM players");
            echo json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));
        } else {
            $stmt = $conn->prepare("SELECT * FROM players WHERE id = ?");
            $stmt->execute([$id]);
            $player = $stmt->fetch(PDO::FETCH_ASSOC);
            if ($player) {
                echo json_encode($player);
            } else {
                http_response_code(404);
                echo json_encode(["error" => "Jucător inexistent"]);
            }
        }
        break;

    case 'POST':
        $input = json_decode(file_get_contents("php://input"), true);
        if (!isset($input['id'], $input['name'])) {
            http_response_code(400);
            echo json_encode(["error" => "Date invalide"]);
            break;
        }
        $stmt = $conn->prepare("SELECT COUNT(*) FROM players WHERE id = ?");
        $stmt->execute([$input['id']]);
        if ($stmt->fetchColumn() > 0) {
            http_response_code(409);
            echo json_encode(["error" => "ID deja existent"]);
            break;
        }
        $stmt = $conn->prepare("INSERT INTO players (id, name) VALUES (?, ?)");
        $stmt->execute([$input['id'], $input['name']]);
        http_response_code(201);
        echo json_encode(["message" => "Jucător creat"]);
        break;

    case 'PUT':
        if ($id === null) {
            http_response_code(400);
            echo json_encode(["error" => "ID lipsă"]);
            break;
        }
        $input = json_decode(file_get_contents("php://input"), true);
        $stmt = $conn->prepare("UPDATE players SET name = ? WHERE id = ?");
        $stmt->execute([$input['name'], $id]);
        if ($stmt->rowCount()) {
            echo json_encode(["message" => "Jucător actualizat"]);
        } else {
            http_response_code(404);
            echo json_encode(["error" => "Jucător inexistent"]);
        }
        break;

    case 'DELETE':
        if ($id === null) {
            http_response_code(400);
            echo json_encode(["error" => "ID lipsă"]);
            break;
        }
        $stmt = $conn->prepare("DELETE FROM players WHERE id = ?");
        $stmt->execute([$id]);
        if ($stmt->rowCount()) {
            http_response_code(204);
        } else {
            http_response_code(404);
            echo json_encode(["error" => "Jucător inexistent"]);
        }
        break;

    default:
        http_response_code(405);
        echo json_encode(["error" => "Metodă neacceptată"]);
}
