<?php
require_once 'db.php';

header("Content-Type: application/json");

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405); 
    echo json_encode(["error" => "Method not allowed"]);
    exit;
}


$path = explode('/', trim($_SERVER['REQUEST_URI'], '/'));
$gameId = isset($path[1]) && is_numeric($path[1]) ? intval($path[1]) : null;

if ($gameId === null) {
    http_response_code(400); 
    echo json_encode(["error" => "Missing or invalid gameId"]);
    exit;
}

$stmt = $db->prepare("SELECT * FROM games WHERE id = ?");
$stmt->execute([$gameId]);
$game = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$game) {
    http_response_code(404);
    echo json_encode(["error" => "Game not found"]);
    exit;
}

$stmt = $db->prepare("UPDATE games SET started = 1 WHERE id = ?");
$stmt->execute([$gameId]);

http_response_code(200);
echo json_encode(["message" => "Game started"]);
