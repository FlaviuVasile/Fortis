<?php
require_once 'db.php';
header("Content-Type: application/json");

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(["error" => "Method not allowed"]);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);
if (!isset($input['gameId'], $input['name'])) {
    http_response_code(400);
    echo json_encode(["error" => "Missing gameId or name"]);
    exit;
}

$gameId = intval($input['gameId']);
$name = trim($input['name']);

$stmt = $mysqli->prepare("SELECT id FROM games WHERE id = ?");
$stmt->bind_param("i", $gameId);
$stmt->execute();
$result = $stmt->get_result();
if ($result->num_rows === 0) {
    http_response_code(404);
    echo json_encode(["error" => "Game not found"]);
    exit;
}

$stmt = $mysqli->prepare("INSERT INTO players (game_id, name) VALUES (?, ?)");
$stmt->bind_param("is", $gameId, $name);
$stmt->execute();
$playerId = $stmt->insert_id;

$stmt = $mysqli->prepare("
    INSERT INTO player_resources (player_id)
    VALUES (?)");
$stmt->bind_param("i", $playerId);
$stmt->execute();

http_response_code(201);
echo json_encode([
    "message" => "Player joined successfully",
    "player_id" => $playerId,
    "game_id" => $gameId,
    "name" => $name
]);
