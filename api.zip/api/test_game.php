<?php
$url = 'http://localhost/fortis/api/join_game.php';

$data = [
    'gameId' => 1,
    'name' => 'TestUser'
];

$options = [
    'http' => [
        'header'  => "Content-type: application/json\r\n",
        'method'  => 'POST',
        'content' => json_encode($data),
    ]
];

$context  = stream_context_create($options);
$result = file_get_contents($url, false, $context);

if ($result === FALSE) {
    echo "Eroare la request!";
} else {
    echo "<pre>$result</pre>";
}
?>
