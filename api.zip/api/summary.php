<?php
require_once 'db.php';

header("Content-Type: application/json");

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    http_response_code(405);
    echo json_encode(["error" => "Method not allowed"]);
    exit;
}

if (!isset($_GET['gameId'])) {
    http_response_code(400);
    echo json_encode(["error" => "Missing gameId"]);
    exit;
}

$gameId = intval($_GET['gameId']);

$stmt = $db->prepare("SELECT * FROM games WHERE id = ?");
$stmt->execute([$gameId]);
$game = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$game) {
    http_response_code(404);
    echo json_encode(["error" => "Game not found"]);
    exit;
}

$player1Id = $game['player1_id'];
$player2Id = $game['player2_id'];
$roundsPlayed = $game['round'];

$stmt = $db->prepare("SELECT player_id, points FROM scores WHERE game_id = ?");
$stmt->execute([$gameId]);
$scores = $stmt->fetchAll(PDO::FETCH_KEY_PAIR);

$score1 = $scores[$player1Id] ?? 0;
$score2 = $scores[$player2Id] ?? 0;

$winner = null;
$loser = null;

if ($score1 != $score2) {
    $winner = ($score1 > $score2) ? $player1Id : $player2Id;
    $loser = ($score1 < $score2) ? $player1Id : $player2Id;
}

$response = [
    "winner_id" => $winner,
    "loser_id" => $loser,
    "rounds_played" => $roundsPlayed,
    "score" => [
        $player1Id => $score1,
        $player2Id => $score2
    ]
];

http_response_code(200);
echo json_encode($response);
