<?php
$host = 'localhost';
$user = 'root';
$password = '1111'; 
$database = 'board_game';

$mysqli = new mysqli($host, $user, $password, $database);

if ($mysqli->connect_errno) {
    echo json_encode(["status" => "fail", "error" => $mysqli->connect_error]);
} else {
    echo json_encode(["status" => "success", "message" => "Conexiune OK"]);
}
