<?php
require_once 'db.php';

header("Content-Type: application/json");

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(["error" => "Method not allowed"]);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);

if (!isset($input['game_id'], $input['player_id'])) {
    http_response_code(400);
    echo json_encode(["error" => "Missing game_id or player_id"]);
    exit;
}

$gameId = intval($input['game_id']);
$playerId = intval($input['player_id']);

$food_needed = 2;

$stmt = $db->prepare("SELECT id FROM players WHERE id = ? AND game_id = ?");
$stmt->execute([$playerId, $gameId]);
if (!$stmt->fetch(PDO::FETCH_ASSOC)) {
    http_response_code(404);
    echo json_encode(["error" => "Player not found in this game"]);
    exit;
}

$stmt = $db->prepare("SELECT food FROM player_resources WHERE game_id = ? AND player_id = ?");
$stmt->execute([$gameId, $playerId]);
$data = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$data) {
    http_response_code(404);
    echo json_encode(["error" => "Player or game not found"]);
    exit;
}

$currentFood = intval($data['food']);

if ($currentFood < $food_needed) {
    http_response_code(400);
    echo json_encode(["error" => "Not enough food to feed the family"]);
    exit;
}

$stmt = $db->prepare("UPDATE player_resources SET food = food - ? WHERE game_id = ? AND player_id = ?");
$stmt->execute([$food_needed, $gameId, $playerId]);

$stmt = $db->prepare("SELECT food FROM player_resources WHERE game_id = ? AND player_id = ?");
$stmt->execute([$gameId, $playerId]);
$updatedResources = $stmt->fetch(PDO::FETCH_ASSOC);

http_response_code(200);
echo json_encode([
    "message" => "Family fed successfully",
    "current_food" => $updatedResources['food']
]);
