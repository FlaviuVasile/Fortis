<?php
$host = '127.0.0.1';
$user = 'root';
$password = '1111'; 
$database = 'board_game';

$mysqli = new mysqli($host, $user, $password, $database);

if ($mysqli->connect_errno) {
    http_response_code(500);
    echo json_encode(["error" => "Conexiune eșuată: " . $mysqli->connect_error]);
    exit;
}


$method = $_SERVER['REQUEST_METHOD'];
$uri = explode("/", trim($_SERVER['REQUEST_URI'], "/"));

if (!isset($uri[1]) || $uri[1] !== "games") {
    http_response_code(404);
    echo json_encode(["error" => "Resursă inexistentă"]);
    exit;
}

$id = isset($uri[2]) && is_numeric($uri[2]) ? intval($uri[2]) : null;

switch ($method) {
    case 'GET':
        if ($id === null) {
            $stmt = $conn->query("SELECT * FROM games");
            echo json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));
        } else {
            $stmt = $conn->prepare("SELECT * FROM games WHERE id = ?");
            $stmt->execute([$id]);
            $game = $stmt->fetch(PDO::FETCH_ASSOC);
            if ($game) {
                echo json_encode($game);
            } else {
                http_response_code(404);
                echo json_encode(["error" => "Joc inexistent"]);
            }
        }
        break;

    case 'POST':
        $input = json_decode(file_get_contents("php://input"), true);
        if (!isset($input['player1_id'], $input['player2_id'])) {
            http_response_code(400);
            echo json_encode(["error" => "Lipsesc player1_id și/sau player2_id"]);
            break;
        }
        $stmt = $conn->prepare("INSERT INTO games (player1_id, player2_id) VALUES (?, ?)");
        $stmt->execute([$input['player1_id'], $input['player2_id']]);
        http_response_code(201);
        echo json_encode(["message" => "Joc creat", "game_id" => $conn->lastInsertId()]);
        break;

    case 'PUT':
        if ($id === null) {
            http_response_code(400);
            echo json_encode(["error" => "ID lipsă"]);
            break;
        }
        $input = json_decode(file_get_contents("php://input"), true);
        if (!isset($input['player1_id'], $input['player2_id'], $input['round'], $input['current_turn'])) {
            http_response_code(400);
            echo json_encode(["error" => "Lipsesc player1_id, player2_id, round sau current_turn"]);
            break;
        }
        $stmt = $conn->prepare("UPDATE games SET player1_id = ?, player2_id = ?, round = ?, current_turn = ? WHERE id = ?");
        $stmt->execute([
            $input['player1_id'],
            $input['player2_id'],
            $input['round'],
            $input['current_turn'],
            $id
        ]);
        echo json_encode(["message" => "Joc actualizat"]);
        break;

    case 'DELETE':
        if ($id === null) {
            http_response_code(400);
            echo json_encode(["error" => "ID lipsă"]);
            break;
        }
        $stmt = $conn->prepare("DELETE FROM games WHERE id = ?");
        $stmt->execute([$id]);
        if ($stmt->rowCount()) {
            http_response_code(204);
        } else {
            http_response_code(404);
            echo json_encode(["error" => "Joc inexistent"]);
        }
        break;

    default:
        header("Allow: GET, POST, PUT, DELETE");
        http_response_code(405);
        echo json_encode(["error" => "Metodă neacceptată"]);
}
