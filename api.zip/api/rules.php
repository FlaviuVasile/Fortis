<?php
require_once 'db.php';

header("Content-Type: application/json");

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    http_response_code(405);
    echo json_encode(["error" => "Method not allowed"]);
    exit;
}

if (!isset($_GET['gameId'])) {
    http_response_code(400);
    echo json_encode(["error" => "Missing gameId"]);
    exit;
}

$gameId = intval($_GET['gameId']);

$stmt = $db->prepare("SELECT round FROM games WHERE id = ?");
$stmt->execute([$gameId]);
$game = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$game) {
    http_response_code(404);
    echo json_encode(["error" => "Game not found. Please check that the provided gameId is correct."]);
    exit;
}

$round = intval($game['round']);

$rulesByRound = [
    1 => ["available_actions" => ["gather_wood", "gather_clay", "take_food"]],
    2 => ["available_actions" => ["gather_wood", "gather_clay", "take_food", "build_room"]],
    3 => ["available_actions" => ["gather_wood", "gather_clay", "build_room", "expand_family"]],
];

$rules = $rulesByRound[$round] ?? ["available_actions" => ["all_actions_unlocked"]];

$response = [
    "round" => $round,
    "rules" => $rules
];

http_response_code(200);
echo json_encode($response);
