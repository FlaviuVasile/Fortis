<?php
require_once 'db.php';
header("Content-Type: application/json");

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    http_response_code(405);
    echo json_encode(["error" => "Method not allowed"]);
    exit;
}

if (!isset($_GET['gameId'])) {
    http_response_code(400);
    echo json_encode(["error" => "Missing gameId"]);
    exit;
}

$gameId = intval($_GET['gameId']);

$stmt = $mysqli->prepare("SELECT id FROM games WHERE id = ?");
$stmt->bind_param("i", $gameId);
$stmt->execute();
$result = $stmt->get_result();
if ($result->num_rows === 0) {
    http_response_code(404);
    echo json_encode(["error" => "Game not found"]);
    exit;
}

$stmt = $mysqli->prepare("SELECT p.id, p.name, p.score, pr.* FROM players p 
    LEFT JOIN player_resources pr ON p.id = pr.player_id
    WHERE p.game_id = ?");
$stmt->bind_param("i", $gameId);
$stmt->execute();
$playersResult = $stmt->get_result();

$players = [];
while ($row = $playersResult->fetch_assoc()) {
    $players[] = [
        "id" => $row['id'],
        "name" => $row['name'],
        "score" => $row['score'],
        "resources" => [
            "wood" => $row['wood'],
            "clay" => $row['clay'],
            "reed" => $row['reed'],
            "stone" => $row['stone'],
            "food" => $row['food'],
            "sheep" => $row['sheep'],
            "pig" => $row['pig'],
            "cow" => $row['cow'],
            "family_members" => $row['family_members'],
            "available_members" => $row['available_members']
        ]
    ];
}

$stmt = $mysqli->prepare("SELECT * FROM board_resources WHERE game_id = ?");
$stmt->bind_param("i", $gameId);
$stmt->execute();
$boardResult = $stmt->get_result();
$board = $boardResult->fetch_assoc() ?? [];

$stmt = $mysqli->prepare("SELECT state FROM game_state WHERE game_id = ?");
$stmt->bind_param("i", $gameId);
$stmt->execute();
$result = $stmt->get_result();
$stateRow = $result->fetch_assoc();
$gameState = $stateRow ? json_decode($stateRow['state'], true) : [];

echo json_encode([
    "game_id" => $gameId,
    "players" => $players,
    "board" => $board,
    "state" => $gameState
]);
