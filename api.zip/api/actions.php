<?php
require_once 'db.php';
header("Content-Type: application/json");

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(["error" => "Method not allowed"]);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);

if (!isset($input['game_id'], $input['player_id'], $input['action_type'])) {
    http_response_code(400);
    echo json_encode(["error" => "Missing game_id, player_id or action_type"]);
    exit;
}

$gameId = intval($input['game_id']);
$playerId = intval($input['player_id']);
$actionType = trim($input['action_type']);
$actionData = isset($input['action_data']) ? json_encode($input['action_data']) : null;

$allowedActions = ['gather_resources', 'build_structure', 'end_turn'];
if (!in_array($actionType, $allowedActions)) {
    http_response_code(400);
    echo json_encode(["error" => "Invalid action type"]);
    exit;
}

if ($actionType === 'gather_resources' && (!isset($input['action_data']['resource']) || !isset($input['action_data']['amount']))) {
    http_response_code(400);
    echo json_encode(["error" => "Missing or invalid resource data"]);
    exit;
}

$stmt = $mysqli->prepare("SELECT id FROM players WHERE id = ? AND game_id = ?");
$stmt->bind_param("ii", $playerId, $gameId);
$stmt->execute();
$result = $stmt->get_result();
if ($result->num_rows === 0) {
    http_response_code(404);
    echo json_encode(["error" => "Player not found in game"]);
    exit;
}

$stmt = $mysqli->prepare("INSERT INTO actions (game_id, player_id, action_type, action_data) VALUES (?, ?, ?, ?)");
$stmt->bind_param("iiss", $gameId, $playerId, $actionType, $actionData);
if (!$stmt->execute()) {
    http_response_code(500);
    echo json_encode(["error" => "Database error: " . $mysqli->error]);
    exit;
}

$actionId = $stmt->insert_id;

$logMessage = "Player $playerId performed action: $actionType";
$stmt = $mysqli->prepare("INSERT INTO logs (game_id, player_id, message) VALUES (?, ?, ?)");
$stmt->bind_param("iis", $gameId, $playerId, $logMessage);
$stmt->execute();

http_response_code(201);
echo json_encode([
    "message" => "Action recorded successfully",
    "action_id" => $actionId,
    "player_id" => $playerId,
    "game_id" => $gameId,
    "action_type" => $actionType,
    "action_data" => json_decode($actionData)
]);
