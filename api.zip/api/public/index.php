<?php
use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;
use Slim\Factory\AppFactory;

require __DIR__ . '/../vendor/autoload.php';

$app = AppFactory::create();

$app->setBasePath('/Fortis/api/public');

$app->addRoutingMiddleware();

$app->addErrorMiddleware(true, true, true);

define('DATA_PATH', realpath(__DIR__ . '/../../data'));
function loadGames() {
    $file = DATA_PATH . '/games.json';

    
    if (!file_exists($file)) {
        
        return [];
    }

    
    $json = file_get_contents($file);

    
    if (empty($json)) {
        return [];
    }

   
    $games = json_decode($json, true);

  
    if (!is_array($games)) {
        return [];
    }

    return $games;
}




function loadPlayers() {
    $json = file_get_contents(DATA_PATH . '/players.json');
    return json_decode($json, true);
}

$app->get('/players', function (Request $request, Response $response, array $args) {
    $players = loadPlayers();

    $response->getBody()->write(json_encode($players));
    return $response->withHeader('Content-Type', 'application/json');
});


$app->post('/players', function (Request $request, Response $response) {
    $data = json_decode($request->getBody()->getContents(), true);

    if (!isset($data['name']) || !isset($data['active'])) {
        $response->getBody()->write(json_encode(['error' => 'Date invalide']));
        return $response->withStatus(400)->withHeader('Content-Type', 'application/json');
    }

    $players = loadPlayers();
    $newId = empty($players) ? 1 : max(array_column($players, 'id')) + 1;

    $newPlayer = [
        'id' => $newId,
        'name' => $data['name'],
        'active' => (bool)$data['active']
    ];

    $players[] = $newPlayer;
    file_put_contents(DATA_PATH . '/players.json', json_encode($players, JSON_PRETTY_PRINT));

    $response->getBody()->write(json_encode($newPlayer));
    return $response->withStatus(201)->withHeader('Content-Type', 'application/json');
});




$app->get('/players/{playerId}', function (Request $request, Response $response, array $args) {
    $players = loadPlayers();
    $playerId = (int)$args['playerId'];  

    foreach ($players as $player) {
        if ($player['id'] === $playerId) {
            $response->getBody()->write(json_encode($player));
            return $response->withHeader('Content-Type', 'application/json');
        }
    }

    $response->getBody()->write(json_encode(['error' => 'Jucător inexistent']));
    return $response->withStatus(404)->withHeader('Content-Type', 'application/json');
});

$app->put('/players/{playerId}', function (Request $request, Response $response, array $args) {
    $playerId = (int)$args['playerId'];
    $data = json_decode($request->getBody()->getContents(), true); // ← AICI schimbarea
    $players = loadPlayers();

    foreach ($players as &$player) {
        if ($player['id'] === $playerId) {
            $player['name'] = $data['name'] ?? $player['name'];
            $player['active'] = $data['active'] ?? $player['active'];

            file_put_contents(DATA_PATH . '/players.json', json_encode($players, JSON_PRETTY_PRINT));
            $response->getBody()->write(json_encode($player));
            return $response->withHeader('Content-Type', 'application/json');
        }
    }

    $response->getBody()->write(json_encode(['error' => 'Jucător inexistent']));
    return $response->withStatus(404)->withHeader('Content-Type', 'application/json');
});

$app->put('/players/{playerId}/status', function (Request $request, Response $response, array $args) {
    $playerId = (int)$args['playerId'];
    $data = json_decode($request->getBody()->getContents(), true);

    if (!isset($data['active'])) {
        $response->getBody()->write(json_encode(['error' => 'Câmpul "active" este necesar']));
        return $response->withStatus(400)->withHeader('Content-Type', 'application/json');
    }

    $players = loadPlayers();

    foreach ($players as &$player) {
        if ($player['id'] === $playerId) {
            $player['active'] = (bool)$data['active'];
            file_put_contents(DATA_PATH . '/players.json', json_encode($players, JSON_PRETTY_PRINT));
            $response->getBody()->write(json_encode(['success' => true]));
            return $response->withHeader('Content-Type', 'application/json');
        }
    }

    $response->getBody()->write(json_encode(['error' => 'Jucător inexistent']));
    return $response->withStatus(404)->withHeader('Content-Type', 'application/json');
});



$app->get('/games', function (Request $request, Response $response, array $args) {
    $games = loadGames();
    $validResources = ['wood', 'clay', 'food', 'reed', 'stone', 'sheep', 'boar', 'cow'];

    foreach ($games as &$game) {
        foreach (['player1_id', 'player2_id'] as $pidKey) {
            $pid = $game[$pidKey] ?? null;
            if ($pid !== null) {
                if (!isset($game['player_resources'][$pid])) {
                    $game['player_resources'][$pid] = array_fill_keys($validResources, 0);
                } else {
                    // Asigură-te că toate resursele sunt setate
                    foreach ($validResources as $res) {
                        if (!isset($game['player_resources'][$pid][$res])) {
                            $game['player_resources'][$pid][$res] = 0;
                        }
                    }
                }
            }
        }
    }

    $response->getBody()->write(json_encode($games));
    return $response->withHeader('Content-Type', 'application/json');
});


$app->post('/games', function (Request $request, Response $response) {
    $data = json_decode($request->getBody()->getContents(), true);

    if (!isset($data['player1_id'])) {
        $response->getBody()->write(json_encode(['error' => 'Lipsește player1_id']));
        return $response->withStatus(400)->withHeader('Content-Type', 'application/json');
    }

    $players = loadPlayers();
    $playerIds = array_column($players, 'id');
    $activeStatus = array_column($players, 'active', 'id');

    if (!in_array($data['player1_id'], $playerIds) || !$activeStatus[$data['player1_id']]) {
        $response->getBody()->write(json_encode(['error' => 'Jucătorul 1 nu există sau nu e activ']));
        return $response->withStatus(400)->withHeader('Content-Type', 'application/json');
    }

    // Căutăm detaliile jucătorului 1
    $player1Data = null;
    foreach ($players as $p) {
        if ($p['id'] === $data['player1_id']) {
            $player1Data = [
                'id' => $p['id'],
                'name' => $p['name']
            ];
            break;
        }
    }

    $games = loadGames();
    $newId = empty($games) ? 1 : max(array_column($games, 'id')) + 1;

    $newGame = [
        'id' => $newId,
        'player1_id' => $data['player1_id'],
        'player2_id' => null,
        'round' => 1,
        'current_turn' => $data['player1_id'],
        'active' => false,
        'score_player1' => 0,
        'score_player2' => 0,
        'board_resources' => [
            'wood' => 0,
            'clay' => 0,
            'food' => 5,
            'reed' => 0,
            'stone' => 0,
            'sheep' => 0,
            'boar' => 0,
            'cow' => 0
        ],
        'players' => $player1Data ? [ $player1Data ] : []
    ];

    $games[] = $newGame;
    file_put_contents(DATA_PATH . '/games.json', json_encode($games, JSON_PRETTY_PRINT));

    $response->getBody()->write(json_encode($newGame));
    return $response->withStatus(201)->withHeader('Content-Type', 'application/json');
});



$app->post('/games/{gameId}/start', function (Request $request, Response $response, array $args) {
    $gameId = (int)$args['gameId'];
    $games = loadGames();

    foreach ($games as &$game) {
        if ($game['id'] === $gameId) {
            // Verificăm dacă jocul are ambii jucători
            if (!isset($game['player1_id']) || !isset($game['player2_id'])) {
                $response->getBody()->write(json_encode(['error' => 'Jocul nu are 2 jucători.']));
                return $response->withStatus(400)->withHeader('Content-Type', 'application/json');
            }

            // Verificăm dacă jocul este deja activ
            if (!empty($game['active'])) {
                $response->getBody()->write(json_encode(['message' => 'Jocul este deja activ.']));
                return $response->withStatus(200)->withHeader('Content-Type', 'application/json');
            }

            // Activăm jocul
            $game['active'] = true;
            $game['round'] = 1;
            $game['current_turn'] = $game['player1_id']; // Sau logică aleatorie dacă vrei

            // Eventual resetăm resursele de pe tablă
            $game['board_resources'] = [
                'wood' => 0,
                'clay' => 0,
                'food' => 5,
                'reed' => 0,
                'stone' => 0,
                'sheep' => 0,
                'boar' => 0,
                'cow' => 0
            ];

            file_put_contents(DATA_PATH . '/games.json', json_encode($games, JSON_PRETTY_PRINT));
            $response->getBody()->write(json_encode(['message' => 'Jocul a început', 'game' => $game]));
            return $response->withHeader('Content-Type', 'application/json');
        }
    }

    $response->getBody()->write(json_encode(['error' => 'Joc inexistent']));
    return $response->withStatus(404)->withHeader('Content-Type', 'application/json');
});


$app->get('/games/active', function (Request $request, Response $response, array $args) {
    $games = loadGames();
    $activeGames = [];

    foreach ($games as $game) {
        if (!empty($game['active']) && $game['active'] === true) {
            $activeGames[] = $game;
        }
    }

    $response->getBody()->write(json_encode($activeGames));
    return $response->withHeader('Content-Type', 'application/json');
});

$app->get('/games/{gameId}', function (Request $request, Response $response, array $args) {
    $games = loadGames();
    $gameId = (int)$args['gameId'];

    foreach ($games as $game) {
        if ($game['id'] === $gameId) {
            $response->getBody()->write(json_encode($game));
            return $response->withHeader('Content-Type', 'application/json');
        }
    }

    $response->getBody()->write(json_encode(['error' => 'Joc inexistent']));
    return $response->withStatus(404)->withHeader('Content-Type', 'application/json');
});


$app->delete('/games/{gameId}', function (Request $request, Response $response, array $args) {
    $gameId = (int)$args['gameId'];
    $games = loadGames();
    $found = false;

    foreach ($games as $index => $game) {
        if ($game['id'] === $gameId) {
            unset($games[$index]);
            $found = true;
            break;
        }
    }

    if (!$found) {
        $response->getBody()->write(json_encode(['error' => 'Joc inexistent']));
        return $response->withStatus(404)->withHeader('Content-Type', 'application/json');
    }

    $games = array_values($games);
    file_put_contents(DATA_PATH . '/games.json', json_encode($games, JSON_PRETTY_PRINT));

    return $response->withStatus(204);
});

$app->put('/games/{gameId}', function (Request $request, Response $response, array $args) {
    $gameId = (int)$args['gameId'];
    $games = loadGames();
    $data = json_decode($request->getBody()->getContents(), true);


    foreach ($games as &$game) {
        if ($game['id'] === $gameId) {
            foreach (['round', 'current_turn', 'score_player1', 'score_player2', 'active'] as $field) {
                if (isset($data[$field])) {
                    $game[$field] = $data[$field]; // ← aici se face update-ul
                }
            }

            file_put_contents(DATA_PATH . '/games.json', json_encode($games, JSON_PRETTY_PRINT));
            $response->getBody()->write(json_encode($game));
            return $response->withHeader('Content-Type', 'application/json');
        }
    }

    $response->getBody()->write(json_encode(['error' => 'Joc inexistent']));
    return $response->withStatus(404)->withHeader('Content-Type', 'application/json');
});




$app->get('/games/{gameId}/summary', function (Request $request, Response $response, array $args) {
    $games = loadGames();
    $gameId = (int)$args['gameId'];

    foreach ($games as $game) {
        if ($game['id'] === $gameId) {
            // 👇 verificare dacă jocul este încă activ
            if (!isset($game['active']) || $game['active']) {
                $response->getBody()->write(json_encode(['error' => 'Jocul este încă activ.']));
                return $response->withStatus(400)->withHeader('Content-Type', 'application/json');
            }

            $summary = [
                'winner_id' => null,
                'loser_id' => null,
                'rounds_played' => $game['round'],
                'score' => [
                    'player1' => $game['score_player1'] ?? null,
                    'player2' => $game['score_player2'] ?? null
                ],
                'draw' => false
            ];

            if (isset($game['score_player1']) && isset($game['score_player2'])) {
                if ($game['score_player1'] > $game['score_player2']) {
                    $summary['winner_id'] = $game['player1_id'];
                    $summary['loser_id'] = $game['player2_id'];
                } elseif ($game['score_player2'] > $game['score_player1']) {
                    $summary['winner_id'] = $game['player2_id'];
                    $summary['loser_id'] = $game['player1_id'];
                } else {
                    $summary['draw'] = true;
                }
            }

            $response->getBody()->write(json_encode($summary));
            return $response->withHeader('Content-Type', 'application/json');
        }
    }

    $response->getBody()->write(json_encode(['error' => 'Joc inexistent']));
    return $response->withStatus(404)->withHeader('Content-Type', 'application/json');
});

$app->post('/games/{gameId}/join', function (Request $request, Response $response, array $args) {
    $gameId = (int)$args['gameId'];
    $data = json_decode($request->getBody()->getContents(), true);

    if (!isset($data['player_id'])) {
        $response->getBody()->write(json_encode(['error' => 'Lipsește player_id']));
        return $response->withStatus(400)->withHeader('Content-Type', 'application/json');
    }

    $playerId = (int)$data['player_id'];
    $players = loadPlayers();
    $games = loadGames();

    // Căutăm jucătorul
    $playerData = null;
    foreach ($players as $p) {
        if ($p['id'] === $playerId && $p['active']) {
            $playerData = $p;
            break;
        }
    }

    if (!$playerData) {
        $response->getBody()->write(json_encode(['error' => 'Jucătorul nu există sau nu este activ']));
        return $response->withStatus(404)->withHeader('Content-Type', 'application/json');
    }

    foreach ($games as &$game) {
        if ($game['id'] === $gameId) {
            // Verificăm dacă jucătorul este deja în joc
            if (
                $playerId === $game['player1_id'] ||
                $playerId === $game['player2_id']
            ) {
                $response->getBody()->write(json_encode(['error' => 'Jucătorul este deja în joc']));
                return $response->withStatus(400)->withHeader('Content-Type', 'application/json');
            }

            // Verificăm dacă jocul are deja ambii jucători
            if (isset($game['player1_id']) && isset($game['player2_id'])) {
                $response->getBody()->write(json_encode(['error' => 'Jocul are deja 2 jucători']));
                return $response->withStatus(400)->withHeader('Content-Type', 'application/json');
            }

            // Alocăm player1 sau player2
            if (!isset($game['player1_id'])) {
                $game['player1_id'] = $playerId;
                $game['current_turn'] = $playerId;
            } elseif (!isset($game['player2_id'])) {
                $game['player2_id'] = $playerId;
            }

            // Inițializăm lista players dacă nu există
            if (!isset($game['players']) || !is_array($game['players'])) {
                $game['players'] = [];
            }

            // Adăugăm jucătorul detaliat în lista `players` doar dacă nu e deja acolo
            $alreadyInList = false;
            foreach ($game['players'] as $p) {
                if ($p['id'] === $playerData['id']) {
                    $alreadyInList = true;
                    break;
                }
            }

            if (!$alreadyInList) {
                $game['players'][] = [
                    'id' => $playerData['id'],
                    'name' => $playerData['name']
                ];
            }

            // Activăm jocul dacă sunt doi jucători
            if (isset($game['player1_id']) && isset($game['player2_id'])) {
                $game['active'] = true;
            }

            file_put_contents(DATA_PATH . '/games.json', json_encode($games, JSON_PRETTY_PRINT));
            $response->getBody()->write(json_encode($game));
            return $response->withStatus(200)->withHeader('Content-Type', 'application/json');
        }
    }

    $response->getBody()->write(json_encode(['error' => 'Joc inexistent']));
    return $response->withStatus(404)->withHeader('Content-Type', 'application/json');
});





$app->get('/games/{gameId}/rules', function (Request $request, Response $response, array $args) {
    $games = loadGames();
    $gameId = (int)$args['gameId'];

    foreach ($games as $game) {
        if ($game['id'] === $gameId) {
            // Regulile jocului
            $rules = [
                'total_rounds' => 14,
                'max_players' => 2,
                'starting_resources' => [
                    'wood' => 0,
                    'clay' => 0,
                    'food' => 5,
                    'reed' => 0,
                    'stone' => 0,
                    'sheep' => 0,
                    'boar' => 0,
                    'cow' => 0
                ]
            ];

            $response->getBody()->write(json_encode($rules));
            return $response->withHeader('Content-Type', 'application/json');
        }
    }

    // Dacă jocul nu există
    $response->getBody()->write(json_encode(['error' => 'Joc inexistent']));
    return $response->withStatus(404)->withHeader('Content-Type', 'application/json');
});

$app->get('/games/{gameId}/board/resources', function (Request $request, Response $response, array $args) {
    $games = loadGames();
    $gameId = (int)$args['gameId'];

    foreach ($games as $game) {
        if ($game['id'] === $gameId) {
            // Verificăm dacă există resurse în joc
            if (isset($game['board_resources'])) {
                $resources = $game['board_resources'];
            } else {
                // Dacă nu există, returnăm resurse goale sau default
                $resources = [
                    'wood' => 0,
                    'clay' => 0,
                    'food' => 0,
                    'reed' => 0,
                    'stone' => 0,
                    'sheep' => 0,
                    'boar' => 0,
                    'cow' => 0
                ];
            }

            $response->getBody()->write(json_encode($resources));
            return $response->withHeader('Content-Type', 'application/json');
        }
    }

    // Dacă jocul nu există
    $response->getBody()->write(json_encode(['error' => 'Joc inexistent']));
    return $response->withStatus(404)->withHeader('Content-Type', 'application/json');
});

$app->put('/games/{gameId}/board/resources', function (Request $request, Response $response, array $args) {
    $gameId = (int)$args['gameId'];
    $data = json_decode($request->getBody()->getContents(), true);

    $validResources = ['wood', 'clay', 'food', 'reed', 'stone','sheep', 'boar', 'cow'];
    $games = loadGames();

    foreach ($games as &$game) {
        if ($game['id'] === $gameId) {
            if (!isset($game['board_resources'])) {
                // Inițializăm dacă lipsește
                $game['board_resources'] = array_fill_keys($validResources, 0);
            }

            foreach ($validResources as $res) {
                if (isset($data[$res]) && is_numeric($data[$res])) {
                    $game['board_resources'][$res] += (int)$data[$res];
                }
            }

            file_put_contents(DATA_PATH . '/games.json', json_encode($games, JSON_PRETTY_PRINT));
            $response->getBody()->write(json_encode(['message' => 'Resursele au fost actualizate', 'board_resources' => $game['board_resources']]));
            return $response->withHeader('Content-Type', 'application/json');
        }
    }

    $response->getBody()->write(json_encode(['error' => 'Joc inexistent']));
    return $response->withStatus(404)->withHeader('Content-Type', 'application/json');
});


$app->post('/games/{gameId}/players/{playerId}/actions/gather', function (Request $request, Response $response, array $args) {
    $gameId = (int)$args['gameId'];
    $playerId = (int)$args['playerId'];
    $data = json_decode($request->getBody()->getContents(), true);

    $validResources = ['wood', 'clay', 'food', 'reed', 'stone', 'sheep', 'boar', 'cow'];

    if (!isset($data['resource_type']) || !in_array($data['resource_type'], $validResources)) {
        $response->getBody()->write(json_encode(['error' => 'Tip de resursă invalid sau lipsă']));
        return $response->withStatus(400)->withHeader('Content-Type', 'application/json');
    }

    $resource = $data['resource_type'];
    $games = loadGames();

    foreach ($games as &$game) {
        if ($game['id'] === $gameId) {
            // Verificăm dacă jucătorul face parte din joc
            if ($playerId !== $game['player1_id'] && $playerId !== $game['player2_id']) {
                $response->getBody()->write(json_encode(['error' => 'Jucătorul nu face parte din joc']));
                return $response->withStatus(403)->withHeader('Content-Type', 'application/json');
            }

            $availableAmount = $game['board_resources'][$resource] ?? 0;

            if ($availableAmount < 1) {
                $response->getBody()->write(json_encode(['error' => 'Nu există resurse disponibile pe tablă']));
                return $response->withStatus(400)->withHeader('Content-Type', 'application/json');
            }

            // Inițializăm player_resources dacă nu există
            if (!isset($game['player_resources'][$playerId])) {
                $game['player_resources'][$playerId] = array_fill_keys($validResources, 0);
            }

            // Transferăm toate resursele disponibile
            $game['player_resources'][$playerId][$resource] += $availableAmount;
            $game['board_resources'][$resource] = 0;

            file_put_contents(DATA_PATH . '/games.json', json_encode($games, JSON_PRETTY_PRINT));

            $response->getBody()->write(json_encode([
                'message' => "Jucătorul a adunat $availableAmount x $resource",
                'board_resources' => $game['board_resources'],
                'player_resources' => $game['player_resources'][$playerId]
            ]));
            return $response->withHeader('Content-Type', 'application/json');
        }
    }

    $response->getBody()->write(json_encode(['error' => 'Joc inexistent']));
    return $response->withStatus(404)->withHeader('Content-Type', 'application/json');
});

$app->post('/games/{gameId}/players/{playerId}/actions/feed', function (Request $request, Response $response, array $args) {
    $gameId = (int)$args['gameId'];
    $playerId = (int)$args['playerId'];
    $data = json_decode($request->getBody()->getContents(), true);

    $requiredFood = $data['required_food'] ?? 2;
    $allowSacrifice = $data['allow_sacrifice'] ?? false;

    $games = loadGames();
    $validResources = ['wood', 'clay', 'food', 'reed', 'stone', 'sheep', 'boar', 'cow'];
    $animalFoodValue = ['cow' => 3, 'boar' => 2, 'sheep' => 1];

    foreach ($games as &$game) {
        if ($game['id'] === $gameId) {
            if ($playerId !== $game['player1_id'] && $playerId !== $game['player2_id']) {
                $response->getBody()->write(json_encode(['error' => 'Jucătorul nu face parte din joc']));
                return $response->withStatus(403)->withHeader('Content-Type', 'application/json');
            }

            if (!isset($game['player_resources'][$playerId])) {
                $game['player_resources'][$playerId] = array_fill_keys($validResources, 0);
            }

            $resources = &$game['player_resources'][$playerId];
            $foodAvailable = $resources['food'] ?? 0;
            $initialFood = $foodAvailable;

            if ($foodAvailable >= $requiredFood) {
                $resources['food'] -= $requiredFood;
                $message = 'Jucătorul a fost hrănit cu succes din food';
            } else {
                $remainingNeed = $requiredFood - $foodAvailable;
                $resources['food'] = 0;
                $foodFromAnimals = 0;
                $sacrificed = [];

                if ($allowSacrifice) {
                    // Sacrificăm animale dacă e permis
                    foreach ($animalFoodValue as $animal => $value) {
                        while ($resources[$animal] > 0 && $foodFromAnimals < $remainingNeed) {
                            $resources[$animal]--;
                            $foodFromAnimals += $value;
                            $sacrificed[$animal] = ($sacrificed[$animal] ?? 0) + 1;
                        }
                    }
                }

                $totalFood = $foodAvailable + $foodFromAnimals;

                if ($totalFood >= $requiredFood) {
                    $excess = $totalFood - $requiredFood;
                    $resources['food'] += $excess; // bonus dacă s-a depășit
                    $message = $allowSacrifice
                        ? 'Jucătorul a fost hrănit din food și animale'
                        : 'Jucătorul a fost hrănit din food (fără sacrificii)';
                } else {
                    $missing = $requiredFood - $totalFood;
                    $game['penalty'][$playerId] = ($game['penalty'][$playerId] ?? 0) + $missing;
                    $message = $allowSacrifice
                        ? "Jucătorul nu a avut destule resurse. Penalizare: $missing"
                        : "Jucătorul a avut doar $foodAvailable food. Penalizare: $missing";
                }
            }

            file_put_contents(DATA_PATH . '/games.json', json_encode($games, JSON_PRETTY_PRINT));

            $response->getBody()->write(json_encode([
                'message' => $message,
                'food_initial' => $initialFood,
                'food_needed' => $requiredFood,
                'allow_sacrifice' => $allowSacrifice,
                'resources' => $resources,
                'sacrificed_animals' => $sacrificed ?? [],
                'penalty' => $game['penalty'][$playerId] ?? 0
            ]));
            return $response->withHeader('Content-Type', 'application/json');
        }
    }

    $response->getBody()->write(json_encode(['error' => 'Joc inexistent']));
    return $response->withStatus(404)->withHeader('Content-Type', 'application/json');
});


$app->post('/games/{gameId}/players/{playerId}/actions/build-house', function (Request $request, Response $response, array $args) {
    $gameId = (int)$args['gameId'];
    $playerId = (int)$args['playerId'];
    $data = json_decode($request->getBody()->getContents(), true);

    $houseType = $data['type'] ?? 'wood'; // 'wood', 'clay', 'stone'
    $validTypes = ['wood', 'clay', 'stone'];
    $costs = [
        'wood' => ['wood' => 5, 'reed' => 2],
        'clay' => ['clay' => 5, 'reed' => 2],
        'stone' => ['stone' => 5, 'reed' => 2],
    ];

    if (!in_array($houseType, $validTypes)) {
        $response->getBody()->write(json_encode(['error' => 'Tip de casă invalid']));
        return $response->withStatus(400)->withHeader('Content-Type', 'application/json');
    }

    $games = loadGames();

    foreach ($games as &$game) {
        if ($game['id'] === $gameId) {
            if (!in_array($playerId, [$game['player1_id'], $game['player2_id']])) {
                $response->getBody()->write(json_encode(['error' => 'Jucătorul nu face parte din joc']));
                return $response->withStatus(403)->withHeader('Content-Type', 'application/json');
            }

            if ($game['current_turn'] !== $playerId) {
                $response->getBody()->write(json_encode(['error' => 'Nu este rândul acestui jucător']));
                return $response->withStatus(403)->withHeader('Content-Type', 'application/json');
            }

            $validResources = ['wood', 'clay', 'food', 'reed', 'stone', 'sheep', 'boar', 'cow'];
            if (!isset($game['player_resources'][$playerId])) {
                $game['player_resources'][$playerId] = array_fill_keys($validResources, 0);
            }

            $playerRes = &$game['player_resources'][$playerId];
            $cost = $costs[$houseType];

            foreach ($cost as $res => $amount) {
                if (($playerRes[$res] ?? 0) < $amount) {
                    $response->getBody()->write(json_encode(['error' => "Resurse insuficiente pentru $res"]));
                    return $response->withStatus(400)->withHeader('Content-Type', 'application/json');
                }
            }

            foreach ($cost as $res => $amount) {
                $playerRes[$res] -= $amount;
            }

            if (!isset($game['player_structures'][$playerId])) {
                $game['player_structures'][$playerId] = ['houses' => []];
            }

            $game['player_structures'][$playerId]['houses'][] = [
                'type' => $houseType,
                'round_built' => $game['round']
            ];

            file_put_contents(DATA_PATH . '/games.json', json_encode($games, JSON_PRETTY_PRINT));

            $response->getBody()->write(json_encode([
                'message' => "Casă construită din $houseType",
                'remaining_resources' => $playerRes,
                'structures' => $game['player_structures'][$playerId]
            ]));
            return $response->withHeader('Content-Type', 'application/json');
        }
    }

    $response->getBody()->write(json_encode(['error' => 'Joc inexistent']));
    return $response->withStatus(404)->withHeader('Content-Type', 'application/json');
});


$app->get('/game/export/scores', function (Request $request, Response $response, array $args) {
    $games = loadGames();
    $scores = [];

    foreach ($games as $game) {
        // Verificăm dacă există scoruri în joc
        if (isset($game['score_player1']) && isset($game['score_player2'])) {
            $scores[] = [
                'game_id' => $game['id'],
                'player1_id' => $game['player1_id'],
                'player2_id' => $game['player2_id'],
                'score_player1' => $game['score_player1'],
                'score_player2' => $game['score_player2']
            ];
        }
    }

    if (empty($scores)) {
        $response->getBody()->write(json_encode(['error' => 'Nu există scoruri de exportat.']));
        return $response->withStatus(404)->withHeader('Content-Type', 'application/json');
    }

    $response->getBody()->write(json_encode($scores));
    return $response->withHeader('Content-Type', 'application/json');
});

$app->get('/game/export/history', function (Request $request, Response $response, array $args) {
    $games = loadGames();
    $history = [];

    foreach ($games as $game) {
        $history[] = [
            'game_id' => $game['id'],
            'player1_id' => $game['player1_id'],
            'player2_id' => $game['player2_id'],
            'rounds_played' => $game['round'],
            'active' => $game['active'] ?? false
        ];
    }

    if (empty($history)) {
        $response->getBody()->write(json_encode(['error' => 'Nu există istoric de jocuri.']));
        return $response->withStatus(404)->withHeader('Content-Type', 'application/json');
    }

    $response->getBody()->write(json_encode($history));
    return $response->withHeader('Content-Type', 'application/json');
});

$app->get('/stats/leaderboard', function (Request $request, Response $response, array $args) {
    $games = loadGames();
    $scores = [];

    foreach ($games as $game) {
        // Adunăm scorurile pentru fiecare jucător
        if (isset($game['score_player1'])) {
            $player1_id = $game['player1_id'];
            $scores[$player1_id] = ($scores[$player1_id] ?? 0) + $game['score_player1'];
        }
        if (isset($game['score_player2'])) {
            $player2_id = $game['player2_id'];
            $scores[$player2_id] = ($scores[$player2_id] ?? 0) + $game['score_player2'];
        }
    }

    if (empty($scores)) {
        $response->getBody()->write(json_encode(['error' => 'Nu există scoruri pentru leaderboard.']));
        return $response->withStatus(404)->withHeader('Content-Type', 'application/json');
    }

    // Transformăm scorurile într-un array de leaderboard
    $leaderboard = [];
    foreach ($scores as $player_id => $total_score) {
        $leaderboard[] = [
            'player_id' => $player_id,
            'total_score' => $total_score
        ];
    }

    // Sortăm descrescător după total_score
    usort($leaderboard, function($a, $b) {
        return $b['total_score'] <=> $a['total_score'];
    });

    $response->getBody()->write(json_encode($leaderboard));
    return $response->withHeader('Content-Type', 'application/json');
});

$app->get('/stats/player/{playerId}', function (Request $request, Response $response, array $args) {
    $games = loadGames();
    $playerId = (int)$args['playerId'];

    $stats = [
        'player_id' => $playerId,
        'games_played' => 0,
        'total_score' => 0,
        'games_won' => 0,
        'games_lost' => 0
    ];

    $playerFound = false;

    foreach ($games as $game) {
        if ($game['player1_id'] === $playerId || $game['player2_id'] === $playerId) {
            $stats['games_played']++;
            $playerFound = true;

            // Adunăm scorul jucătorului
            if ($game['player1_id'] === $playerId && isset($game['score_player1'])) {
                $stats['total_score'] += $game['score_player1'];
            }
            if ($game['player2_id'] === $playerId && isset($game['score_player2'])) {
                $stats['total_score'] += $game['score_player2'];
            }

            // Verificăm cine a câștigat
            if (isset($game['score_player1']) && isset($game['score_player2'])) {
                if ($game['score_player1'] > $game['score_player2']) {
                    if ($game['player1_id'] === $playerId) {
                        $stats['games_won']++;
                    } elseif ($game['player2_id'] === $playerId) {
                        $stats['games_lost']++;
                    }
                } elseif ($game['score_player2'] > $game['score_player1']) {
                    if ($game['player2_id'] === $playerId) {
                        $stats['games_won']++;
                    } elseif ($game['player1_id'] === $playerId) {
                        $stats['games_lost']++;
                    }
                }
                // dacă e egalitate, nu numărăm câștig sau pierdere
            }
        }
    }

    if (!$playerFound) {
        $response->getBody()->write(json_encode(['error' => 'Jucător inexistent sau fără jocuri.']));
        return $response->withStatus(404)->withHeader('Content-Type', 'application/json');
    }

    $response->getBody()->write(json_encode($stats));
    return $response->withHeader('Content-Type', 'application/json');
});

$app->get('/state/{gameId}', function (Request $request, Response $response, array $args) {
    $games = loadGames();
    $gameId = (int)$args['gameId'];

    foreach ($games as $game) {
        if ($game['id'] === $gameId) {
            $state = [
                'game_id' => $game['id'],
                'round' => $game['round'],
                'current_turn' => $game['current_turn'],
                'board_resources' => $game['board_resources'] ?? [
                    'wood' => 0,
                    'clay' => 0,
                    'food' => 0,
                    'reed' => 0,
                    'stone' => 0
                ],
                'players' => $game['players'] ?? []
            ];

            $response->getBody()->write(json_encode($state));
            return $response->withHeader('Content-Type', 'application/json');
        }
    }

    $response->getBody()->write(json_encode(['error' => 'Joc inexistent']));
    return $response->withStatus(404)->withHeader('Content-Type', 'application/json');
});

    



$app->run();
 