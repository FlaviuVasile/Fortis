<?php
$host = '127.0.0.1';
$user = 'root';
$password = '1111';
$database = 'board_game';

$mysqli = new mysqli($host, $user, $password, $database);

if ($mysqli->connect_errno) {
    http_response_code(500);
    echo json_encode(["error" => "Conexiune eșuată: " . $mysqli->connect_error]);
    exit;
}


$method = $_SERVER['REQUEST_METHOD'];
$uri = explode("/", trim($_SERVER['REQUEST_URI'], "/"));

if (!isset($uri[2]) || $uri[1] !== "games" || $uri[3] !== "board-resources") {
    http_response_code(404);
    echo json_encode(["error" => "Resursă inexistentă"]);
    exit;
}

$gameId = intval($uri[2]);

$stmt = $conn->prepare("SELECT id FROM games WHERE id = ?");
$stmt->execute([$gameId]);
if (!$stmt->fetch(PDO::FETCH_ASSOC)) {
    http_response_code(404);
    echo json_encode(["error" => "Joc inexistent"]);
    exit;
}

switch ($method) {
    case 'GET':
        $stmt = $conn->prepare("SELECT wood, clay, food, reed, stone, pig, cow, sheep FROM board_resources WHERE game_id = ?");
        $stmt->execute([$gameId]);
        $resources = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($resources) {
            echo json_encode([
                "message" => "Resurse găsite",
                "data" => $resources
            ]);
        } else {
            http_response_code(404);
            echo json_encode(["error" => "Resurse inexistente pentru acest joc"]);
        }
        break;

    case 'PUT':
        $input = json_decode(file_get_contents("php://input"), true);

        if (!is_array($input)) {
            http_response_code(400);
            echo json_encode(["error" => "Date de intrare invalide"]);
            exit;
        }

        $stmt = $conn->prepare("
            INSERT INTO board_resources (game_id, wood, clay, food, reed, stone, pig, cow, sheep)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            ON DUPLICATE KEY UPDATE 
                wood = VALUES(wood),
                clay = VALUES(clay),
                food = VALUES(food),
                reed = VALUES(reed),
                stone = VALUES(stone),
                pig = VALUES(pig),
                cow = VALUES(cow),
                sheep = VALUES(sheep)
        ");

        $stmt->execute([
            $gameId,
            $input['wood'] ?? 0,
            $input['clay'] ?? 0,
            $input['food'] ?? 0,
            $input['reed'] ?? 0,
            $input['stone'] ?? 0,
            $input['pig'] ?? 0,
            $input['cow'] ?? 0,
            $input['sheep'] ?? 0
        ]);

        echo json_encode([
            "message" => "Resurse actualizate",
            "data" => $input
        ]);
        break;

    default:
        header("Allow: GET, PUT");
        http_response_code(405);
        echo json_encode(["error" => "Metodă neacceptată"]);
}
