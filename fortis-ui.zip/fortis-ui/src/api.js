const API_BASE = "/Fortis/api/public";

export async function createGame(name) {
  const res = await fetch(`${API_BASE}/games`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ name })
  });
  return await res.json();
}

export async function getGames() {
  const res = await fetch(`${API_BASE}/games`);
  return await res.json();
}

export async function joinGame(name, gameId) {
  const res = await fetch(`${API_BASE}/game/join`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ name, gameId })
  });
  return await res.json();
}
