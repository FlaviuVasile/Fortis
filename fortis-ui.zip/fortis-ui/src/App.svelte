<script>
  import StartScreen from './components/StartScreen.svelte';
  import GameBoard from './components/GameBoard.svelte';
  import PlayerCard from './components/PlayerCard.svelte';
  import { gameBoard, players } from './data/mock.js';

  let playerName = "";
  let gameId = null;
  let ready = false;

  function handleStart({ name, gameId: id, role }) {
    playerName = name;
    gameId = id;

    // Pentru acum, pornim jocul direct
    // Mai târziu putem face verificare dacă amândoi sunt conectați
    ready = true;
  }
</script>

{#if !ready}
  <StartScreen onStart={handleStart} />
{:else}
  <main class="p-6 space-y-6">
    <h2 class="text-2xl font-bold">Bine ai venit, {playerName}!</h2>
    <p>Joci în jocul #{gameId}</p>

    <GameBoard board={gameBoard} />
    <div class="grid sm:grid-cols-2 gap-4">
      {#each players as player}
        <PlayerCard {player} />
      {/each}
    </div>
  </main>
{/if}
