export const gameBoard = {
  wood: 5,
  clay: 3,
  stone: 2,
  reed: 1,
  sheep: 2,
  boar: 1,
  cow: 1
};

export const players = [
  {
    id: 1,
    name: "Ana",
    resources: {
      wood: 2,
      clay: 1,
      food: 3,
      cow: 1
    }
  },
  {
    id: 2,
    name: "Mihai",
    resources: {
      wood: 1,
      sheep: 2,
      food: 4
    }
  }
];
