<script>
  import { createGame, getGames, joinGame } from '../api.js';
  export let onStart;

  let name = "";
  let step = "input"; // input, list
  let games = [];
  let error = "";

  async function handleCreateGame() {
    if (name.trim().length === 0) return;
    try {
      const game = await createGame(name);
      onStart({ name, gameId: game.id, role: 'creator' });
    } catch (err) {
      error = err.message;
    }
  }

 async function handleJoinList() {
  if (name.trim().length === 0) return;
  try {
    const allGames = await getGames();
    // filtrăm doar jocurile active false (adică neîncepute)
    games = allGames.filter(game => !game.active);
    step = "list";
  } catch (err) {
    error = "Nu s-au putut încărca jocurile.";
  }
}


  async function handleJoin(gameId) {
    try {
      await joinGame(name, gameId);
      onStart({ name, gameId, role: 'joiner' });
    } catch (err) {
      error = "Eroare la alăturare la joc.";
    }
  }
</script>

<div class="flex flex-col items-center justify-center min-h-screen bg-green-100 text-center">
  <h1 class="text-4xl font-bold mb-6">Agricola</h1>

  {#if step === 'input'}
    <input
      bind:value={name}
      placeholder="Introdu numele tău"
      class="p-2 rounded border mb-4 w-64 text-center"
    />

    <div class="flex flex-col gap-2">
      <button on:click={handleCreateGame} class="bg-green-600 text-white px-4 py-2 rounded shadow w-64">
        Creează joc nou
      </button>

      <button on:click={handleJoinList} class="bg-blue-600 text-white px-4 py-2 rounded shadow w-64">
        Conectează-te la un joc
      </button>
    </div>
  {/if}

  {#if step === 'list'}
    <h2 class="text-xl font-semibold mb-2">Alege un joc activ</h2>
    {#if games.length === 0}
      <p class="text-gray-600">Nu există jocuri disponibile.</p>
    {:else}
      <ul class="space-y-2">
        {#each games as game}
          <li class="bg-white rounded shadow p-2 w-64 mx-auto flex justify-between items-center">
            <span>Joc #{game.id}</span>
            <button on:click={() => handleJoin(game.id)} class="bg-blue-500 text-white px-2 py-1 rounded">
              Join
            </button>
          </li>
        {/each}
      </ul>
    {/if}
  {/if}

  {#if error}
    <p class="text-red-600 mt-4">{error}</p>
  {/if}
</div>
