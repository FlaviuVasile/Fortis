<script>
  export let player;
</script>

<div class="bg-white p-4 rounded-xl shadow w-full">
  <h3 class="text-lg font-semibold mb-2">{player.name}</h3>
  <div class="grid grid-cols-3 gap-1 text-sm mb-2">
    {#each Object.entries(player.resources) as [type, amount]}
      <div>{type}: {amount}</div>
    {/each}
  </div>
  <div class="flex gap-2">
    <button class="px-3 py-1 bg-blue-500 text-white rounded">Gather</button>
    <button class="px-3 py-1 bg-green-600 text-white rounded">Feed</button>
  </div>
</div>
