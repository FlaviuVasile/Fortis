<script>
  export let board;
</script>

<div class="p-4 bg-gray-100 rounded-xl shadow mb-6">
  <h2 class="text-xl font-bold mb-2">Tabla jocului</h2>
  <div class="grid grid-cols-3 gap-2">
    {#each Object.entries(board) as [type, amount]}
      <div class="bg-white p-2 rounded shadow">
        <strong>{type}:</strong> {amount}
      </div>
    {/each}
  </div>
</div>
